var form = document.getElementById("form");
var campos = document.getElementsByClassName("obrigatorio");
var infos = document.getElementsByClassName("info");


function mostraErro(index) {
    campos[index].style.border = "1px solid red";
    infos[index].style.display = "block";
}

function ocultaErro(index) {
    campos[index].style.border = "";
    infos[index].style.display = "none";

}

function validaSenha() {
    if (campos[0].value.length < 10) {
        mostraErro(0);
    } else {
        ocultaErro(0);
    }
}
